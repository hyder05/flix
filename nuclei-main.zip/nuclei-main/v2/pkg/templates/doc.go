// Package templates contains the parser for a template for the engine.
package templates
