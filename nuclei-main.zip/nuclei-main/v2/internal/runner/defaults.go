package runner

const (
	// Default directory used to save protocols traffic
	DefaultDumpTrafficOutputFolder = "output"
)
